/**
 * JS for component: `form`
 */

// initialize components
$('select').formSelect();
$('*[data-length]').characterCounter();
M.Range.init($('*[type=range]'));