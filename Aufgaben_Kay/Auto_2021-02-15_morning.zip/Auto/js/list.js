/**
 * JS for component: `list`
 */

// get data from JSON
// $.getJSON("data/api.php",
//     function(data) {

//     }
// );

// initial data fetch
getData(0);

// sort btns
$('button.sort').click(function(e) {
    e.preventDefault();
    var limit = Number($(this).data('value'));
    console.log(limit);

    getData(limit);
});


function getData(limit = 0) {
    $.ajax({
        type: "GET",
        url: "data/api.php?action=get&limit=" + limit,
        data: "",
        dataType: "json",
        success: function(data) {
            // template for new records
            var template = $('#record-template').html();
            // render html with data
            var html = Mustache.render(template, data);
            // assign to table
            $('#table-body').html(html);


            // !: After assignment add events
            $('.mode-tanken').click(function(e) {
                e.preventDefault();
                let id = $(this).parent().data('id');
                console.log('MODE: tanken - ID: ' + id);

                $.ajax({
                    type: "GET",
                    url: "data/api.php?action=tanken&id=" + id,
                    data: "",
                    dataType: "json",
                    success: function(response) {
                        console.log(response);
                        getData();
                    }
                });

            });

            $('.mode-edit').click(function(e) {
                e.preventDefault();
                let id = $(this).parent().data('id');
                console.log('MODE: edit - ID: ' + id);

                // set modal html
                $('#modal-title').html('Edit - ID: ' + $(this).parent().data('id')); // * Get parent and read attr `data-id` => data('id')

                $('data-form').load("sites/form.html", function() {
                    console.log('INFO: form loaded')
                    $.getScript("js/form.js", function() {
                        console.log('INFO: form JS loaded');
                        // fetch data
                        $.ajax({
                            type: "GET",
                            url: "data/api.php?action=get&id=" + id,
                            data: "",
                            dataType: "json",
                            success: function(response) {
                                $('#field-id').val(response['data'][0]['id']);
                                $('#field-name').val(response['data'][0]['name']);
                                $('#field-bauart').val(response['data'][0]['bauart']);
                                $('#field-kraftstoff').val(response['data'][0]['kraftstoff']);
                                $('#field-farbe').val(response['data'][0]['color']);
                                $('#field-tank').val(response['data'][0]['tank']);

                                // update the text fields
                                M.updateTextFields();
                                $('select').formSelect();

                                // open modal after all
                                var instance = M.Modal.getInstance($('#modal'));
                                instance.open();
                            }
                        });
                    });
                });
            });

            $('.mode-delete').click(function(e) {
                e.preventDefault();
                let id = $(this).parent().data('id');
                console.log('MODE: delete - ID: ' + id);

                var check = confirm('Do you want to delete the record: ' + id + '?');
                if (check) {
                    $.ajax({
                        type: "GET",
                        url: "data/api.php?action=delete&id=" + id,
                        data: "",
                        dataType: "json",
                        success: function(response) {
                            console.log(response);
                            getData();
                        }
                    });
                }

            });
            // !: End event register

        }
    });

}