/**
 * JS for component: `index`
 */

$(function() {
    // modal 
    $('.modal').modal();

    // footer text with year
    var date = new Date();
    $('#footer-text').html('© ' + date.getFullYear() + ' My Company');

    // onclick events
    $('data-table').load("sites/list.html", function() {
        console.log('INFO: data table loaded');
        $.getScript("js/list.js", function() {
            console.log('INFO: data table JS loaded');
        });
    });

    $('#modal-save').click(function(e) {
        e.preventDefault();

        // get id from input field
        var id = Number($('#field-id').val());

        // get form data
        var name = $('#field-name').val();
        var bauart = $('#field-bauart').val();
        var kraftstoff = $('#field-kraftstoff').val();
        var color = $('#field-farbe').val();
        var tank = $('#field-tank').val();

        // TODO Validation
        if ($(name).hasClass(className) && $(bauart).hasClass(className)) {

        }

        var instance = M.Modal.getInstance($('#modal'));
        instance.close();

        // check for id and update & create
        if (id > 0) {
            $.ajax({
                type: "POST",
                url: "data/api.php?action=update&id=" + id,
                data: {
                    'name': name,
                    'bauart': bauart,
                    'kraftstoff': kraftstoff,
                    'color': color,
                    'tank': tank
                },
                dataType: "json",
                success: function(response) {
                    console.log(response);
                    showToasts(response);
                    getData();
                }
            });
        } else {
            $.ajax({
                type: "POST",
                url: "data/api.php?action=create",
                data: {
                    'name': name,
                    'bauart': bauart,
                    'kraftstoff': kraftstoff,
                    'color': color,
                    'tank': tank
                },
                dataType: "json",
                success: function(response) {
                    console.log(response);
                    showToasts(response);
                    getData();
                }
            });
        }


    });

    $('.mode-new').click(function(e) {
        e.preventDefault();

        $('#modal-title').html('New');
        $('#field-id').val(0);

        $('data-form').load("sites/form.html", function() {
            console.log('INFO: form loaded')
            $.getScript("js/form.js", function() {
                console.log('INFO: form JS loaded');
                // update the text fields
                M.updateTextFields();
                $('select').formSelect();

                // open modal after all
                var instance = M.Modal.getInstance($('#modal'));
                instance.open();
            });
        });

    });

});

function showToasts(data) {
    // * Message handling
    if (data['success'].length > 0) {
        data['success'].forEach(element => {
            console.log(element);
            M.toast({ html: element, classes: 'green' });
        });
    }
    if (data['error'].length > 0) {
        console.log("err");
        data['error'].forEach(element => {
            M.toast({ html: element['message'], classes: 'red' });
            console.error(element['message']);
        });
    }
    // * END Message handling
}